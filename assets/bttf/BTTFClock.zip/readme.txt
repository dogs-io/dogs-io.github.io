BTTF Clock v 1.0.1
https://dogs-io.com/#/bttf

Freeware written by Sergei Bazarnik
------------------------------------
Travel through time—right from your screen!
The BTTFClock  Screensaver brings the legendary Delorean
Time Circuits dashboard to your Windows or macOS computer.

This screensaver is developed by a Back to the Future fan, for fans, 
and is completely free with no ads, 
no tracking, 
and no data collection. 
Just pure nostalgia.


• Accurate Time Circuits display (Present / Destination / Last Time Departed)
• Authentic BTTF-inspired design
• Supports multiple monitor setups
• Lightweight and doesn’t affect system performance
• Free and ad-free
• Multi-monitor support: The screensaver automatically runs on all connected displays.(Windows only)

Installation (Windows):
1. Extract the ZIP.
2. Right-click "BTTF Clock.scr" and choose “Install”.
3. Or copy the "BTTF Clock.scr" file to C:\Windows\System32.

Installation (macOS):
1. Extract the ZIP.
2. Double-click the "BTTFClock.saver" file.
3. Click “Install” when System Settings asks to add the screensaver.

This screensaver is free and created by a "Back To The Future" fan for fans.
Enjoy!


